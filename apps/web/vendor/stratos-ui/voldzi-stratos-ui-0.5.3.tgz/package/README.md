# @voldzi/stratos-ui

Shared STRATOS UI component library for STRATOS applications and approved external applications that must keep UI compatibility.

## Install

The package is distributed as a public npm package. The current published
baseline recorded at handoff is `0.3.37`; this monorepo uses `0.5.1` through
`workspace:*`. Its shared appearance and central SSO additions described below
are **not included in that published version**. An
external consumer can use the verified `0.5.3` acceptance tarball in
`vendor/stratos-ui` before a separate npm release. Copy the tarball into the
consumer's own Docker build context and lock its integrity; never link to
the STRATOS workspace outside that context. This is the same npm package
format (dist, declarations, CSS and public exports), not a consumer source fork.
A source version bump is not proof of registry publication.

```json
{
  "dependencies": {
    "@voldzi/stratos-ui": "^0.3.37"
  }
}
```

Consumers do not need a GitHub Packages token for this package. If an
application also consumes private `@voldzi/*` packages from GitHub Packages, do
not copy that scope-level registry configuration into applications that only
need `@voldzi/stratos-ui`; otherwise npm will resolve this public package from
the wrong registry.

For the acceptance tarball, use `pnpm add ./vendor/stratos-ui/voldzi-stratos-ui-0.5.3.tgz`
from the consuming package and commit the artifact plus lockfile. The local
path must stay inside the consumer Docker build context. Production registry
consumption remains the standard after the separately authorized npm release.
The `0.5.3` release keeps the topbar, root and CSS exports used by AKB 0.3.37;
Chat is additive and requires `appUrls.chat` plus an `akb:chat` projection.
Its optional auth monitor cancels on hide/pagehide, resumes on visible/focus/
pageshow, and never writes explicit-logout state. Only a user logout action
may call `markSignedOut()`. Active-page 401/403/unavailable verification must
still clear protected UI in the host application's `invalid` callback.

## Publishing To npm

The verified release path uses the repository runtime for checks and Node
`22.21.1` with npm `10.9.4` for the interactive npm publish. Do not publish with
the repository's Node 24 / npm 11 client, do not use a heredoc, and do not bump
the version inside the publishing command.

First set the intended version explicitly, commit-ready but not yet published.
Then run from `packages/stratos-ui`:

```bash
mise exec -- pnpm release:npm
```

The script:

- exits successfully when the local version already exists on npm,
- detects an expired npm token,
- removes only the invalid npmjs token entry and starts `npm login --auth-type=web`,
- waits for browser authentication in Safari,
- runs the complete package check,
- publishes through Node `22.21.1` with progress disabled and bounded fetch retries.

When npm prints `Press ENTER to open in the browser`, press Enter, approve the
request in Safari, return to the terminal and wait for:

```text
+ @voldzi/stratos-ui@<version>
```

After a successful release, commit `packages/stratos-ui/package.json` and any
intentional release-script or lockfile changes. Never increase the version
again merely because GitHub push is temporarily unavailable.

## Required CSS

Import the shared stylesheet once in the application root:

```tsx
import "@voldzi/stratos-ui/styles.css";
```

`styles.css` includes STRATOS tokens and component styles. `tokens.css` is exported separately only for advanced host styling.

## Appearance

Apply the saved appearance once at the application shell. System mode follows
operating-system changes and the cleanup returned by the helper is suitable for
a React effect:

```tsx
useEffect(
  () => applyStratosAppearance({ theme: settings.theme, highContrast: settings.highContrast }),
  [settings.theme, settings.highContrast]
);
```

The helper owns `data-stratos-theme`, `data-stratos-theme-preference`,
`data-stratos-high-contrast` and `color-scheme` on the document root. Application
styles should consume STRATOS tokens or scope their dark/high-contrast overrides
to these attributes; do not implement a second theme state.

To avoid a light-theme flash before React hydration, render
`STRATOS_APPEARANCE_BOOTSTRAP_SCRIPT` in the root layout `<head>`, set
`suppressHydrationWarning` on `<html>` and advertise `colorScheme: "light dark"`.
The script reads only the narrow, appearance-only snapshot written by
`storeStratosAppearancePreference`; the authenticated profile endpoint remains
the authoritative source and replaces that snapshot after hydration.

Applications that deliberately split their CSS can import component families
through stable modular style entrypoints:

```tsx
import "@voldzi/stratos-ui/styles/tokens.css";
import "@voldzi/stratos-ui/styles/layout.css";
import "@voldzi/stratos-ui/styles/popovers.css";
import "@voldzi/stratos-ui/styles/tables.css";
import "@voldzi/stratos-ui/styles/kanban.css";
import "@voldzi/stratos-ui/styles/settings.css";
import "@voldzi/stratos-ui/styles/uploads-workflow.css";
import "@voldzi/stratos-ui/styles/dialog.css";
```

Use the full `styles.css` import for normal STRATOS apps. Use modular imports
only when the application has a measured first-screen bundle/style constraint.

## Stable Exports

The following exports are stable for cross-application usage:

- `ProjectTopbar`
- `GlobalTopbar`
- `TopbarStatusIndicator`
- `CommandCenter`
- `UnifiedSelect`
- `ProjectPicker`
- `DirectoryPersonPicker`
- `SettingsSurface`
- `SurfaceModeMenu`
- `DetailSurface`
- `SurfaceState`
- `EmptyState`
- `PermissionState`
- `ReadonlyState`
- `PortalPopover`
- `SearchBox`
- `FilterBuilderSurface`
- `EntityContextMenu`
- `DragList`
- `KanbanBoard`
- `KanbanItemsBoard`
- `ExecutiveMetricStrip`
- `MetricCard`
- `DataTable`
- `StructuredList`
- `DateRangePicker`
- `HelpHint`
- `FieldLabelWithHelp`
- `AkbDocumentPicker`
- `AkbDocumentViewer`
- `AkbDocumentUpload`
- `AkbDocumentStatusBadge`
- `StratosDocumentPreview`
- `StratosPdfViewer` through `@voldzi/stratos-ui/pdf`
- `validateStratosDocumentPreviewDescriptor`
- `normalizeStratosDocumentPreviewDescriptor`
- `mergeStratosProfileSettings`
- `createStratosProfileSettingsPayload`
- `createStratosProfileSettingsClient`

`broadcastStratosProfileSettingsUpdate` and
`subscribeStratosProfileSettingsUpdate` are also exported for cross-tab profile
UI refresh after a host application saves `GET/PUT /api/v1/profile/settings`.
They are not a persistence layer; backend profile settings remain the source of
truth.

Applications should pass localized labels, domain data and callbacks through props. The package must not be forked locally for visual compatibility.

## Central SSO Entry (Repository Implementation, Not Yet Published)

`@voldzi/stratos-ui/auth` is a browser-only subpath exposing
`createStratosBrowserOidcClient`, `StratosOidcClientConfiguration`,
`StratosSsoError` and the common safe failure states. The root component
export `StratosSignInState` renders the matching loading, sign-in, signed-out
and verification/error states without an application-level “remember me”
checkbox. It accepts `applicationName`, `busy`, `failure` and `onSignIn`.
Its common messages follow the explicit CS/EN locale or the document language. These exports require the new source
build; they must not be advertised as available in npm `0.3.37`.

```tsx
import { StratosSignInState } from "@voldzi/stratos-ui";
import { createStratosBrowserOidcClient } from "@voldzi/stratos-ui/auth";

// Host-owned BFF callbacks and trusted runtime configuration are supplied
// by the consuming application, not discovered by the shared library.
const sso = createStratosBrowserOidcClient({
  storagePrefix: "application.oidc",
  exchangeCode: exchangeCodeWithBff
});

// Initial entry: verify the application's own HttpOnly session first.
const result = await sso.restore(configuration, readCurrentBffSession);

// Pass this handler to onSignIn; do not retry automatically after restore.
// Use reauthenticate: true only for an explicit step-up action.
const onSignIn = () => sso.begin(configuration, { manual: true });
```

Use one stable client instance per application and an application-specific
`storagePrefix`. The host provides the validated issuer/discovery endpoint,
client ID, exact redirect URI, scopes and configuration version. It owns BFF
HTTP calls, CSRF protection, token verification, authorization and encrypted
server-side token storage. The helper does not call any domain API, own a
user grant, infer a role or approve a session. `exchangeCode` currently
includes compatibility `rememberDevice: false`; that field is not authority
for persistence. The BFF uses the signed central session-policy claims.

Behavior shared across consumers:

- A verified initial BFF HTTP `401` may start one top-level Code + PKCE
  authorization request. Standard entry does not force `prompt=login` or
  `max_age=0`; explicit `reauthenticate: true` does both.
- Callback errors, state/issuer/configuration mismatches, `403`, transport
  failure and offline state do not trigger an automatic redirect loop.
  The per-tab attempt guard has no timed retry; recovery requires an explicit
  action, successful session verification, or a new tab lifecycle.
- PKCE state/verifier transactions expire after 10 minutes. Return paths
  stay same-origin and callback credentials are removed from navigation URLs.
- New OIDC transactions require working `sessionStorage`, including manual
  retries. An already valid HttpOnly BFF session can still be used when that
  storage is unavailable; there is no bearer/localStorage fallback.
- The host calls `markSignedOut()` on explicit logout before its central
  end-session flow. The marker suppresses automatic re-entry in that tab; it
  is a UX guard, never authorization or a substitute for server revocation.

Remembering a device is selected only on central sign-in. Each application
retains its own narrowly scoped BFF cookie. Do not implement hidden-iframe
login, a broad shared `Domain` cookie, or cross-origin bearer-token sharing.
See the repository's `docs/65_CENTRAL_SSO.md` for the BFF policy, coordinated
rollout and acceptance matrix. AKB owns its BFF integration and package
adoption separately.

## Executive Metrics

Use `ExecutiveMetricStrip` for the primary summary above a workspace. It accepts
at most four decision-oriented `MetricCard` instances and owns a container-aware
responsive layout: four columns in a wide workspace, two in a narrow workspace,
and a horizontal scroll-snap strip at mobile width. Applications provide domain data and ordering, not a local
replacement grid.

`MetricCard` is static by default. It renders as a native link only when `href`
is provided and as a native button only when `onActivate` is provided. Use
`actionLabel` when the visible content does not fully describe that action.
For a metric that also serves as workspace navigation, set `active` only on the
currently open destination; the shared component then exposes the common active
appearance and `aria-current="page"`. Static metric cards ignore this navigation
state.
Available evidence states are `ready`, `loading`, `no-data`, `partial`, and
`stale`; missing or incomplete data must not be represented as zero or as a
complete current result.

Pass `chartData` only for a real, traceable series or aggregation. Synthetic,
random, and decorative trend series are not allowed. Provide `trendLabel` to
describe the series to assistive technologies, use `meta` for period or source
context, and apply `emphasis="primary"` to no more than one metric in a strip.

## Shell And Navigation

`AppShell` uses `100dvh` with `100vh` fallback and renders the workspace
sidebar as a drawer on mobile and compact tablet viewports. Pass
`sidebarCloseLabel` for localized drawer close controls; applications can
override the close control through `renderSidebarClose`. When the nested
`WorkspaceSidebar` already renders `onClose`, set `showSidebarClose={false}` on
`AppShell` so the drawer has exactly one close action.

Mobile shell contract: at `max-width: 768px`, `AppShell` always gives
`.stratos-app-shell-main` and `.stratos-app-shell-content` the full viewport
content column. Rail is hidden, sidebar is fixed drawer, and consumers should
not add application CSS overrides for `.stratos-app-shell-main`,
`.stratos-app-shell-content` or `.stratos-global-topbar-context` just to repair
mobile layout.

`GlobalTopbar` app switcher items support `href`, `target`, `rel` and
`external` in addition to `onSelect`. Prefer `href` for app-to-app navigation
so browser navigation, copy-link behavior and base-path routing stay native.
STRATOS applications must use the shared registry through `currentAppId` and
`appUrls`; they must not duplicate application names, icons or ordering. The
current application remains visible in the switcher trigger and is omitted
from the destination menu by default. `showCurrentAppInMenu` exists only as a
compatibility escape hatch. The lower-level `apps` prop remains available for
non-STRATOS consumers.

```tsx
<GlobalTopbar
  currentAppId="akb"
  appUrls={{
    "budget-contract": process.env.NEXT_PUBLIC_STRATOS_HOME_URL,
    projectflow: process.env.NEXT_PUBLIC_PROJECTFLOW_URL,
    archflow: process.env.NEXT_PUBLIC_ARCHFLOW_URL
  }}
  appAvailability={buildStratosAppsAvailabilityFromAccessProjection(authMe.applicationAccess)}
  labels={labels}
/>
```

Use `appAvailability` only for role/environment visibility and enabled state.
The default product switcher contains only Budget & Contract, ProjectFlow, AKB
and ArchFlow. Retired applications are deliberately absent from this shared
product surface.
STRATOS hosts should build it with
`buildStratosAppsAvailabilityFromAccessProjection(authMe.applicationAccess)`
so the access locks and labels stay identical across applications.
Ordinary missing application access must remain visible and navigable so the
target application can render the shared denied page. Use
`access: "missing"` with an optional localized `accessLabel`; reserve
`visible: false` for an application hidden by organization or environment
policy and `enabled: false` for a genuinely unavailable destination.

```tsx
<GlobalTopbar
  currentAppId="budget-contract"
  appAvailability={{
    projectflow: { access: "missing", accessLabel: "Bez přístupu" }
  }}
  // ...
/>
```

### Access states

`AccessBoundary` provides one reason-code contract for the whole STRATOS
suite. `StratosApplicationAccessPage` renders the full application denial
inside the host application's global shell. `StratosAuthErrorPage` renders
authentication, expired-session and fail-closed access-verification states
without exposing raw backend error messages. Capability and scope denial stay
compact through `RestrictedContentState`.
It does not authorize access; every target application must enforce its own
server-side authorization.

Use `overflowActions` for lower-priority topbar actions and
`actionsCollapse="mobile"` or `actionsCollapse="tablet"` when inline actions
should collapse on narrow viewports. `mobileBehavior` controls small viewport
priority for `context`, `actions` and `status`; the default hides context,
keeps status compact and moves inline actions out of the way when overflow
actions are supplied.

Use shared topbar primitives instead of application-local CSS for standard
slots:

```tsx
<GlobalTopbar
  context={
    <GlobalTopbarBreadcrumb
      items={[
        { id: "app", label: "ArchFlow" },
        { id: "route", label: "Potreby", current: true }
      ]}
    />
  }
  center={<CommandCenterTrigger label="Hledat nebo spustit akci" onClick={openCommandCenter} />}
  status={
    <TopbarStatusGroup
      items={[
        {
          id: "saved",
          label: "Ulozeno",
          tone: "good",
          icon: <Check size={14} />
        }
      ]}
    />
  }
/>
```

`AppRail` can render a mobile bottom navigation fallback with
`mobileFallback="bottom"`. Use it when rail items are the primary application
sections and the host app does not provide an equivalent mobile section
switcher. Use `onMobileItemSelect` when mobile taps should directly switch a
section instead of reusing a desktop rail handler that opens a sidebar panel.

For the standard rail + section sidebar pattern, use
`useRailSectionSidebarController`. It centralizes desktop toggle behavior,
mobile bottom-rail behavior and overlay sidebar close-after-navigation logic:

```tsx
const railSidebar = useRailSectionSidebarController({
  activeSectionId,
  sidebarOpen,
  onSectionChange: setActiveSectionId,
  onSidebarOpenChange: setSidebarOpen,
  overlayMediaQuery: "(max-width: 1100px)"
});

<AppRail
  items={sections}
  activeItemId={activeSectionId}
  panelOpen={sidebarOpen}
  mobileFallback="bottom"
  onItemSelect={railSidebar.selectRailItem}
  onMobileItemSelect={railSidebar.selectMobileRailItem}
/>

<WorkspaceSidebar title={activeTitle} closeLabel="Skryt panel" onClose={railSidebar.closeSidebar}>
  <WorkspaceNav groups={activeGroups} onNavigate={railSidebar.closeSidebarAfterNavigation} />
</WorkspaceSidebar>
```

`WorkspaceNav` supports `renderLink` for router integrations:

```tsx
<WorkspaceNav
  groups={groups}
  renderLink={({ href, className, children, onClick, ariaCurrent, title }) => (
    <Link href={href} className={className} onClick={onClick} aria-current={ariaCurrent} title={title}>
      {children}
    </Link>
  )}
/>
```

## Kanban Board

Use `KanbanItemsBoard` for standard status boards where the application can
provide a flat item list, a status getter and a move callback. Use the lower
level `KanbanBoard` only when the application owns custom drag behavior or
pre-grouped columns.

```tsx
import { KanbanCardTitle, KanbanItemsBoard } from "@voldzi/stratos-ui";

<KanbanItemsBoard
  columns={[
    { id: "planned", title: "Planned", emptyLabel: "No planned work" },
    { id: "active", title: "Active" },
    { id: "done", title: "Done" }
  ]}
  items={tasks}
  getItemId={(item) => item.id}
  getItemColumnId={(item) => item.status}
  onItemMove={({ item, toColumnId }) => updateTaskStatus(item.id, toColumnId)}
  renderCard={({ item }) => <KanbanCardTitle>{item.title}</KanbanCardTitle>}
/>;
```

`KanbanBoard` still owns column/card layout, drop targets, drag preview styling
and common card primitives. Host applications keep their domain model,
permissions, inline editors and persistence callbacks.

On mobile, the board uses horizontal scroll snap. Set
`mobileEmptyColumns="hide"` when empty stages should not consume the first
viewport, and provide `instructions` for the localized keyboard/swipe hint.
`KanbanItemsBoard` supports Alt+ArrowLeft/ArrowRight moves whenever
`onItemMove` is present; set `enableKeyboardMove={false}` only when the domain
workflow must prohibit direct stage changes.

For controlled stage-gate boards, omit `onItemMove` or pass
`enableNativeDrag={false}`. Cards then render as neutral containers instead of
fake draggable buttons, so host-rendered links and action buttons remain the
only interactive controls.

## Profile Settings Contract

Every STRATOS application must persist user-facing profile settings through the
shared backend contract:

```json
{
  "settings": {
    "core": {
      "avatarId": "teal",
      "avatarImageUrl": "",
      "displayName": "Portfolio manager",
      "language": "cs",
      "theme": "system",
      "accent": "teal"
    },
    "apps": {
      "budget": {
        "compactTables": true
      }
    }
  }
}
```

Use `settings.core` for values shared across apps and
`settings.apps.<appId>` for app-specific defaults. Host applications should use
the shared helpers instead of duplicating profile merge logic:

```tsx
import { createStratosProfileSettingsPayload, mergeStratosProfileSettings } from "@voldzi/stratos-ui";

const draft = normalizeDraft(
  mergeStratosProfileSettings(profileResponse, "budget", {
    compactTables: ["compactTables", "compactMode"]
  })
);

await api.put(
  "/api/v1/profile/settings",
  createStratosProfileSettingsPayload(
    {
      avatarId: draft.avatarId,
      avatarImageUrl: draft.avatarImageUrl,
      displayName: draft.displayName,
      language: draft.language,
      theme: draft.theme,
      accent: draft.accent
    },
    "budget",
    { compactTables: draft.compactTables }
  )
);
```

`createStratosProfileSettingsClient` is available for small host apps that want
a typed client around `GET/PUT /api/v1/profile/settings`. Larger apps may keep
their existing API clients but should still use the shared merge and payload
helpers.

## Directory Person Picker

Use `DirectoryPersonPicker` whenever an application assigns a person, owner,
manager, approver or watcher from an organization directory. STRATOS
applications must not use free-text person fields for structured workflow
ownership.

```tsx
import { DirectoryPersonPicker } from "@voldzi/stratos-ui";

<DirectoryPersonPicker
  people={directoryPeople}
  selectedPersonId={ownerId}
  labels={{
    title: "People",
    search: "Search directory...",
    placeholder: "Select person"
  }}
  onPersonSelect={(personId, person) => updateOwner(person.name)}
/>;
```

The host application remains responsible for tenant-scoped directory data,
identity mapping and persistence. The shared component owns the trigger,
popover, search, selected state and multi-select behavior.

`ProjectPicker` and `DirectoryPersonPicker` render their selection surface
through the shared `PortalPopover`, so they work inside tables, detail panels
and overflow-hidden dashboards. Use `popoverPlacement` and `popoverMinWidth`
only when a concrete layout needs a different alignment; do not fork local
person/project picker popovers. Use `popoverClassName` only for layout-scoped
host adjustments such as width or z-index.

## Field Help

Use `HelpHint` and `FieldLabelWithHelp` for short contextual help in forms.
This is intended for officer-facing workflows where the screen must stay clean
but users need a quick explanation of a field or decision.

```tsx
import { FieldLabelWithHelp, HelpHint, SelectField } from "@voldzi/stratos-ui";

<FieldLabelWithHelp
  htmlFor="classification"
  label="Classification"
  required
  helpLabel="Classification help"
  helpText="Choose the lowest classification that matches the content."
/>

<SelectField
  id="document-type"
  label="Document type"
  labelAccessory={<HelpHint label="Document type help" text="Type improves filtering and reporting." />}
  description="Choose the closest document type."
>
  <option value="directive">Directive</option>
  <option value="methodology">Methodology</option>
</SelectField>
```

## File Upload

`FileDropzone` owns file selection, native drag and drop, client-side file
constraints, progress presentation, keyboard behavior and accessible status
announcements. The host owns transport, parsing, malware/DLP checks, preview,
commit and domain errors.

```tsx
import { FileDropzone } from "@voldzi/stratos-ui";

<FileDropzone
  accept={{
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document": [".docx"]
  }}
  files={selectedFiles}
  maxSize={8 * 1024 * 1024}
  multiple={false}
  state={uploadState}
  progress={uploadProgress}
  onFilesSelected={setSelectedFiles}
  onRemoveFile={() => setSelectedFiles([])}
/>;
```

`required` renders the shared required mark and `optional` renders the localized
`optionalLabel`. Do not put an asterisk directly into the field label.

## Dialogs

Use `Dialog` for short create, rename, confirmation and configuration forms.
It owns the portal, backdrop, Escape behavior, focus trap, focus return, body
scroll lock, viewport height and sticky header/footer.

```tsx
<Dialog
  open={open}
  title="Create team"
  subtitle="Add the basic team information."
  onClose={() => setOpen(false)}
  onSubmit={submit}
  footer={
    <Button type="submit" variant="primary">
      Create
    </Button>
  }
>
  {formFields}
</Dialog>
```

Use `DetailSurface` instead when the surface is a persistent object detail that
can switch between modal, sidebar and fullscreen modes. Applications must not
reimplement dialog backdrops or focus traps in local CSS.

Do not put server validation or application-specific upload calls into the
component. Pass server failures through `state="error"` and
`validationErrors` after the host has mapped them to localized user messages.

## Workflow Participants

`WorkflowParticipants` is controlled and role-agnostic. Applications provide
role definitions, directory subjects and assignments; the component provides
the shared compact layout, directory interactions, primary participant,
delegate and advanced SLA/escalation controls.

```tsx
import { WorkflowParticipants } from "@voldzi/stratos-ui";

<WorkflowParticipants
  mode="edit"
  roles={[
    {
      id: "decision-owner",
      name: "Decision owner",
      required: true,
      minAssignments: 1,
      maxAssignments: 2,
      allowedSubjectTypes: ["person", "group"]
    }
  ]}
  subjects={directorySubjects}
  assignments={assignments}
  validationMode={saveAttempted ? "always" : "onSubmit"}
  onAssignmentsChange={setAssignments}
/>;
```

Use `validationMode="onSubmit"` before the first save attempt so required-role
errors do not appear when a form is initially opened. Switch to `always` after
the first attempt. Explicit host or server `validationErrors` remain visible in
both modes.

`DirectorySubjectPicker` is exported separately for applications that need the
same person, group and organizational-unit picker outside workflow roles.
Technical subject ids are used only as controlled values; the visible primary
value is always the supplied subject name. Authorization, directory loading,
workflow routing, persistence, audit and server validation remain in the host.

## AKB Document AI Components

AKB-specific document components are also available through a dedicated subpath:

```tsx
import { AkbDocumentPicker, AkbDocumentViewer, AkbDocumentUpload, AkbDocumentStatusBadge } from "@voldzi/stratos-ui/akb";
```

The PDF viewer is intentionally available through a separate subpath so
applications can lazy-load it only when a user opens a PDF preview:

```tsx
const StratosPdfViewer = lazy(() =>
  import("@voldzi/stratos-ui/pdf").then((module) => ({
    default: module.StratosPdfViewer
  }))
);
```

Use this pattern for report previews, document modals and other heavy surfaces
that are not required for the first screen. Keep the main `@voldzi/stratos-ui`
barrel for always-visible shell, toolbar, data and widget components.

These components call only the approved AKB web/API bridge and AKB-hosted
viewer/embed URLs. Host applications pass business context such as tenant,
external system, entity type/id and context tags; AKB remains responsible for
document storage, current version metadata, upload, ingestion, retrieval,
citation opening, authorization and audit.

`AkbDocumentViewer` requests a short-lived AKB `source-open` decision and then
renders the signed source content through an in-memory browser `blob:` URL. This
keeps AKB as the source of truth while avoiding reverse-proxy frame headers on
the signed binary endpoint.
The viewer may follow AKB-controlled redirects to the signed source endpoint,
but it rejects authentication redirects and HTML responses so a login page cannot
be rendered as a document.
PDF sources are rendered by the shared `StratosPdfViewer` with page navigation,
zoom, fit-to-width, rotation, download/open actions and the standard STRATOS
surface mode switcher (`modal`, `fullscreen`, `sidebar`). Applications should
not fork a local PDF preview for AKB documents.

`AkbDocumentViewer` also accepts AKB preview descriptors through
`previewDescriptor` and will render descriptors returned from future AKB
`source-open` responses under `preview` or `document_preview`. The descriptor is
rendered by `StratosDocumentPreview`, which covers PDF, image, text, Markdown,
CSV, JSON/XML/HTML-as-text, DOCX paragraph previews, XLSX sheet previews, PPTX
slide previews, unsupported states and Archi/ArchiMate model previews. The
Archi preview is intentionally structural: model metadata, elements,
relationships and views. Pixel-perfect Office rendering, OCR, conversion,
ArchiMate diagram layout and authorization remain AKB responsibilities.
The shared library exports `STRATOS_DOCUMENT_PREVIEW_LABELS`,
`validateStratosDocumentPreviewDescriptor`,
`normalizeStratosDocumentPreviewDescriptor` and
`STRATOS_DOCUMENT_PREVIEW_FIXTURES` so every STRATOS app can validate, localize
and demo the same AKB preview contract without duplicating UI logic.

Host applications store only AKB reference metadata such as `documentId`,
`documentVersionId`, `externalDocumentId`, `fileId`, `ingestionJobId`,
`ingestionStatus` and canonical open URLs returned by AKB. They must not store
binary files, extracted text, chunks, embeddings, RAG answers or LLM outputs as
a parallel source of truth outside AKB.

Default bridge/viewer paths:

```http
POST /akb/api/stratos/documents/search
GET  /api/v1/budget-control/contracts/{id}/akb/admission
POST /api/v1/budget-control/contracts/{id}/akb/upload/preflight
PUT  /api/v1/budget-control/contracts/{id}/akb/upload/sessions/{sessionId}/content
POST /api/v1/budget-control/contracts/{id}/akb/upload/sessions/{sessionId}/confirm
GET  /akb/api/stratos/documents/{document_id}/open-url
POST /akb/api/stratos/documents/{document_id}/source-open?version_id=...
GET  /akb/api/stratos/documents/{document_id}/ingestion-status
POST /akb/api/stratos/documents/{document_id}/retry-ingestion
GET  /akb/api/stratos/citations/{chunk_id}/open-url
GET  /akb/api/documents/source/content?token=...
```


## Quality contract (0.3.41 source)

Explicit `locale` takes precedence over the document language; an unknown or
absent language falls back to Czech. Text/label overrides take precedence over
the built-in copy. Consumers must load the shared tokens plus their selected
style modules, or the complete CSS entry. Tokens also supply the common motion
and typography boundary for standalone components and body portals.

- DateRangePicker is date-only. Recurrence is displayed only when both
  `showRecurring` and `onRecurring` are supplied. Arrow keys move by day/week,
  Home/End by week boundary, PageUp/PageDown by month (Shift by year).
- UnifiedSelect paginates at 50 options; filtering spans the complete collection.
  Arrows/Home/End cross pages and skip disabled entries. Selection is retained
  independently of the currently visible page.
- PDF downloads and initializes once per source URL (excluding fragment); page,
  zoom, rotation and resize reuse the document. Source changes/unmount cancel
  work. No persistent document cache is created.
- Settings use a section selector below 960px. Saving retains focus, announces
  failure/success and preserves consumer-owned drafts. Dialog/settings exits
  retain modal ownership for 140ms; reduced motion removes the animation.
  Keep the component mounted with `open={false}` to animate its exit.
- `pnpm check` includes gzip budgets for independent ESM imports and full CSS.
  `pnpm test:interactions:serve` exposes the synthetic catalog at `/?quality`,
  settings/table states at `/?matrix`, and remote search at `/?remote`.
- `pnpm test:interactions:ci` runs keyboard, 100k-row, 5k-choice, real PDF, axe,
  contrast, reduced motion and visual regressions in the pinned Linux image.
  Baseline updates are intentional: `STRATOS_UI_UPDATE_SNAPSHOTS=1 pnpm
  test:interactions:ci`; inspect the changed PNGs before committing them.
  Local Chrome runs the behavioral checks; pixel comparison uses Linux only.

These gates cover representative library states. They do not replace a real
screen-reader check, physical mobile devices or a balanced executive/daily-user
pilot, and do not certify every downstream application.


## Coordinated document intake (0.4.1 source)

Breaking upload protocol: the browser sends bytes only to its STRATOS BFF and
uses encrypted short-lived tickets. Only the server handles AKB upload tokens,
receipts, storage addresses and service authentication. The component requires
an approved TLP/steward/profile before upload, exposes real workflow phases and
never invents transfer percentages. Non-Budget source adapters remain explicitly
unavailable until independently approved. FileDropzone has one keyboard target;
its labelled native file input is separate, without nested interactive controls.
